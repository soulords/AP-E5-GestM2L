<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/getAllReservations','RestApiController@getAllRservations')->name('getAllReservations');
Route::get('/tests','RestApiController@tests')->name('tests');
Route::get('/getAllInterventions','RestApiController@getAllInterventions')->name('getAllInterventions');
Route::get('/Interventions','RestApiController@Interventions')->name('Interventions');